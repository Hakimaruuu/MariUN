/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Modul;

/**
 *
 * @author rizki
 */
public class Soal {
    private int no;
    private String text;
    private String paket;
    private String jawaba;
    private String jawabb;
    private String jawabc;
    private String jawabd;
    private String jawabanbenar;

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getPaket() {
        return paket;
    }

    public void setPaket(String paket) {
        this.paket = paket;
    }

    public String getJawaba() {
        return jawaba;
    }

    public void setJawaba(String jawaba) {
        this.jawaba = jawaba;
    }

    public String getJawabb() {
        return jawabb;
    }

    public void setJawabb(String jawabb) {
        this.jawabb = jawabb;
    }

    public String getJawabc() {
        return jawabc;
    }

    public void setJawabc(String jawabc) {
        this.jawabc = jawabc;
    }

    public String getJawabd() {
        return jawabd;
    }

    public void setJawabd(String jawabd) {
        this.jawabd = jawabd;
    }

    public String getJawabanbenar() {
        return jawabanbenar;
    }

    public void setJawabanbenar(String jawabanbenar) {
        this.jawabanbenar = jawabanbenar;
    }

    public Soal(int no, String text, String paket, String jawaba, String jawabb, String jawabc, String jawabd, String jawabanbenar) {
        this.no = no;
        this.text = text;
        this.paket = paket;
        this.jawaba = jawaba;
        this.jawabb = jawabb;
        this.jawabc = jawabc;
        this.jawabd = jawabd;
        this.jawabanbenar = jawabanbenar;
    }
}
