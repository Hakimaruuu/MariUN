/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Modul;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Database {
    private String url = "";
    private String user = "";
    private String pass = "";
    public Connection conn;
    public Statement statement;
    public String SQL;
   
     public void connect(){
        try{
            String url = "jdbc:mysql://localhost/mariun";
            String user = "root";
            String pass = "";
            conn = (Connection) DriverManager.getConnection(url,user,pass);
            statement = (Statement) conn.createStatement();
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    public ResultSet getDatabase(String SQL) throws SQLException{
        ResultSet res = statement.executeQuery(SQL);
        return res;
    }
    public void updateDatabase(String SQL) throws SQLException{
        statement.executeUpdate(SQL);
    }
}
