/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Modul;

import java.util.Date;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rizki
 */
public class Cookies {
    
    //variable
    public static ArrayList listsoal= new ArrayList();
    public static int icookies = 0;
    public static int scookies = 0;
    public static double siswascore = 0;
    public static String useractive = "";
    public static String pelajaranactive = "";
    public static String paketactive = "";
    public static String passwordactive = "";
    public static ArrayList jawabanbenar = new ArrayList();
    public static String nisnactive = "";
    
    //untuk form tambah soal
    public static int nosoal;
    public void setNoSoal(int nosoal){
        this.nosoal = nosoal;
    }
    public int getNosoal(){
        return nosoal;
    }
    
    
    //variabel ambil tanggal
    public static DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    public void setDate(DateFormat sdf){
        Cookies.sdf = sdf;
    }
    public DateFormat getDate(){
        return sdf;
    }
    //dalam bentuk string
    public String getStringDate(){
        return sdf.format(new Date());
    }
    
    
    //untuk buat siswa di database
    public static void createSiswaData(String username, String nama, String password, String nisn){
        Connection con;
        Statement st;
        ResultSet rs;
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        
        String sql = "insert into user values ('"+username+ "','"+nama+"','"+password+"','"+nisn+"', 'no');";
        try {
            rs = st.executeQuery(sql);
            System.out.println("DATABASE:");
            System.out.println("create siswa sukses");
            
        } catch (SQLException ex) {
            Logger.getLogger(Cookies.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //untuk upload histori siswa
    public static void uploadSiswaNilaiData(String nisn, String pelajaran, String paket, double score) throws SQLException{
        Connection con;
        Statement st;
        ResultSet rs;
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        System.out.println("di nisn active :"+nisn); 
        String a =Timestamp.valueOf(LocalDateTime.now()).toString();
        try {
            String pel = "insert into historisiswa values (?,?,?,?,?);";
        PreparedStatement ps = con.prepareStatement(pel);
        ps.setString(1, a);
        ps.setString(3, pelajaran);
        ps.setString(4, paket);
        ps.setDouble(2, score);
        ps.setString(5,nisn);
        ps.executeUpdate(); 
        System.out.println("insert histori "+nisn+" sukses");
        } catch (SQLException ex) {
            Logger.getLogger(Cookies.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("    ");
    }
}
