/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Database {
    private String url = "jdbc:mysql://localhost:3306/pbo";
    private String user = "root";
    private String pass = "";
    private Connection conn;
    private Statement statement;
    private String SQL;
    public Database(){
        try {
            conn = (Connection) DriverManager.getConnection(url, user, pass);
            statement = (Statement) conn.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public ResultSet getDatabase(String SQL) throws SQLException{
        ResultSet res = statement.executeQuery(SQL);
        return res;
    }
    public void updateDatabase(String SQL) throws SQLException{
        statement.executeUpdate(SQL);
    }
    
}
