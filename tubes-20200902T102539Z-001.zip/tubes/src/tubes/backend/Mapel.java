/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Mapel implements Nameable {
    private String idMapel;
    private String namaMapel;
    private Soal[] soal;

    public Mapel(String idMapel, String namaMapel) {
        this.idMapel = idMapel;
        this.namaMapel = namaMapel;
    }

    @Override
    public String getName() {
        return namaMapel;
    }

    public String getIdMapel() {
        return idMapel;
    }

    public String getNamaMapel() {
        return namaMapel;
    }

    public Soal[] getSoal() {
        return soal;
    }
    
}
