/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Admin extends User implements Nameable {
    private String username;
    private String nama;
    

    public String getUsername() {
        return username;
    }

    public String getNama() {
        return nama;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public void setNama(String nama) {
        this.nama = nama;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getName() {
        return nama;
    }

    public Admin(String username, String nama) {
        this.username = username;
        this.nama = nama;
    }
    
}
