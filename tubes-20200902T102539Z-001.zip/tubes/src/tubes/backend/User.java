/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author IRFANUL ARIFA
 */
public abstract class User implements Nameable{
    protected String username;
    protected String password;
    
    public abstract String getPassword();
    
    public abstract String getUsername();
    
    public abstract void setNama(String nama);
    
    public abstract void setPassword(String password);
}
