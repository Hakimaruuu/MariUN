/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Guru extends User implements Nameable{
    private String nip;
    private Mapel[] mp;
    private Siswa[] sis;
    private String namaguru;

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public Mapel[] getMp() {
        return mp;
    }

    public void setMp(Mapel[] mp) {
        this.mp = mp;
    }

    public Siswa[] getSis() {
        return sis;
    }

    public void setSis(Siswa[] sis) {
        this.sis = sis;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public void setNama(String nama) {
        this.namaguru = nama;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getName() {
        return namaguru;
    }

    public Guru(String nip, Mapel[] mp, Siswa[] sis, String namaguru) {
        this.nip = nip;
        this.mp = mp;
        this.sis = sis;
        this.namaguru = namaguru;
    }
    
}
