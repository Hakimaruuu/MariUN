/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Siswa extends User implements Nameable {
    private String nisn;
    private double nilai;
    private String namasiswa;

    public String getNisn() {
        return nisn;
    }

    public void setNisn(String nisn) {
        this.nisn = nisn;
    }

    public double getNilai() {
        return nilai;
    }

    public void setNilai(double nilai) {
        this.nilai = nilai;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public void setNama(String nama) {
        this.namasiswa = nama;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getName() {
        return namasiswa;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public Siswa(String nisn, double nilai, String namasiswa) {
        this.nisn = nisn;
        this.nilai = nilai;
        this.namasiswa = namasiswa;
    }
    
}
