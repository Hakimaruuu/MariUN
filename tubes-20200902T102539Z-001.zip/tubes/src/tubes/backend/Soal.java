/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Soal implements Nameable {
    private String namasoal;
    private int nomorsoal;
    private String idSoal;
    @Override
    public String getName() {
        return namasoal;
    }

    public String getNamasoal() {
        return namasoal;
    }

    public int getNomorsoal() {
        return nomorsoal;
    }

    public String getIdSoal() {
        return idSoal;
    }
    
}
