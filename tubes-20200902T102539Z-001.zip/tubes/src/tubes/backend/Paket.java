/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.backend;

/**
 *
 * @author IRFANUL ARIFA
 */
public class Paket implements Nameable {
    private String idPaket;
    private String namaPaket;
    private String[] soal;
    private String[] jawaban;
    
    public Paket(String idPaket, String namaPaket, String idMapel) {
        this.idPaket = idPaket;
        this.namaPaket = namaPaket;
    }

    @Override
    public String getName() {
        return namaPaket;
    }

    public String getIdPaket() {
        return idPaket;
    }

    public String getNamaPaket() {
        return namaPaket;
    }

    public void setSoal(String[] soal) {
        this.soal = soal;
    }

    public void setJawaban(String[] jawaban) {
        this.jawaban = jawaban;
    }
    
}
