/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import static tubes.Modul.Cookies.nisnactive;
import static tubes.Modul.Cookies.paketactive;
import static tubes.Modul.Cookies.pelajaranactive;
import static tubes.Modul.Cookies.siswascore;
import static tubes.Modul.Cookies.uploadSiswaNilaiData;
import static tubes.Modul.Cookies.useractive;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class HasilSiswaController implements Initializable {

    private Connection con;
    private ResultSet rs;
    private Statement st;
    @FXML
    private Label labelpelajaranpaket;
    @FXML
    private ScrollPane paneSuper;
    @FXML
    private Label noSoal;
    @FXML
    private Button keluarButton;
    @FXML
    private Label noSoal1121;
    @FXML
    private TextArea textfield;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        labelpelajaranpaket.setText(pelajaranactive + " " + paketactive);
        System.out.println("siswa score = "+siswascore);
        System.out.println("nisn = "+nisnactive);
        System.out.println("    ");
        
        //pernakpernik
        
        String index = ""; String smgt = "";
        if(siswascore>80){
            index = "A";
            smgt = "Selamat! Pertahankan terus prestasinya!!";
        } else if (siswascore>60 && siswascore<79){
            index = "B";
            smgt = "Semangat! Tingkatkan terus belajarnya!!";
        } else {
            index = "C";
            smgt = "Tingkatkan belajarnya, jangan berkecil hati!!";
        }
        textfield.setText("Dear "+useractive+",\n" +
                "\n" +
                "Setelah mengerjakan soal "+pelajaranactive+" "+paketactive+",\n" +
                "adik mendapat skor : "+siswascore+"  dengan index :"+index+".\n" +
                "\n" + 
                smgt +
                "\n" +
                "\n" +
                "Bandung, "+Timestamp.valueOf(LocalDateTime.now())+"\n" +
                        "-MariUN(2019)");
    }    

    @FXML
    private void keluarButtonAction(ActionEvent event) throws IOException, SQLException {
        System.out.println("init upload");
        
        //database upload ke histori kerjakan siswa
         uploadSiswaNilaiData(nisnactive, pelajaranactive, paketactive, siswascore);
        System.out.println("upload done");
        
        //clear untuk next use
        siswascore = 0; pelajaranactive = ""; paketactive = "";
        System.out.println("clear pelajaran, paket, siswa score");
        
        //go back
        Stage stage = null; Parent root = null; Scene scene = null;
        stage = (Stage) keluarButton.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("/tubes/View/userDashboard.fxml"));
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
}
