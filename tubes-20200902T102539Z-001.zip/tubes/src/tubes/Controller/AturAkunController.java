/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import static tubes.Modul.Cookies.nisnactive;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class AturAkunController implements Initializable {
    //DATABASE
    Connection con;
    ResultSet rs;
    Statement st;
    PreparedStatement ps;
    
    @FXML
    private Button gantiButton;
    @FXML
    private TextField newPassword;
    @FXML
    private TextField oldPassword;

    String theoldPass = "";
    @FXML
    private Label infolabel;
    @FXML
    public void gantiButtonAction(ActionEvent e) throws SQLException{
        
        try{
            String sql = "select * from user;";
            rs = st.executeQuery(sql);
            while(rs.next()){
                if (nisnactive.equals(rs.getString("nisn"))){
                    theoldPass = rs.getString("password");
                }   
            }
            infolabel.setText("");
            //jika verifikasi benar 
             if (newPassword.getText().equals("") && oldPassword.getText().equals("")){
                infolabel.setText("Data harus diisi!");
            //jika verifikasi benar tapi passwordnya sama saja
            } else if(newPassword.getText().equals(theoldPass)&& oldPassword.getText().equals(theoldPass)){
                infolabel.setText("Password sama dengan yang lama");
            //password verifikasi kosong
            } else if(!newPassword.getText().isEmpty() && oldPassword.getText().isEmpty()){
                infolabel.setText("Password lama kosong");
            } else if (!newPassword.getText().isEmpty() && !oldPassword.getText().equals(theoldPass)){
                infolabel.setText("Password lama salah");
            } else if(newPassword.getText().isEmpty() && oldPassword.getText().equals(theoldPass)){
                infolabel.setText("Password baru tidak bisa kosong");
            } else if(newPassword.getText().isEmpty() && !oldPassword.getText().equals(theoldPass)){
                infolabel.setText("Password lama salah");
            } else if(newPassword.getText().equals(theoldPass)&&oldPassword.getText().equals(theoldPass)){
                infolabel.setText("Password sama");
            } else if (oldPassword.getText().equals(theoldPass) && !newPassword.getText().isEmpty()){
                String sqli = "update user set password = ? where nisn = ? ;";
                ps = con.prepareStatement(sqli);
                ps.setString(1, newPassword.getText());
                ps.setString(2, nisnactive);
                ps.executeUpdate();
                infolabel.setText("Data diganti");
                System.out.println("execute update success");
            //jika semua field kosong
            }  else {
                infolabel.setText("Password tidak diterima");
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
        oldPassword.clear(); newPassword.clear(); 
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
    }    
    
}
