/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import tubes.Modul.Cookies;
import static tubes.Modul.Cookies.jawabanbenar;
import static tubes.Modul.Cookies.icookies;
import static tubes.Modul.Cookies.paketactive;
import static tubes.Modul.Cookies.pelajaranactive;
import static tubes.Modul.Cookies.siswascore;
import tubes.Modul.Database;
import tubes.Modul.Soal;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class IndoPaneSoalController implements Initializable {
    //variabel
    ArrayList<Soal> listsoal = new ArrayList<>();
    ArrayList<Character> pilihan = new ArrayList<>();
    ArrayList<String> listjawabansoal = new ArrayList<>();
    ArrayList<String> listjawabansiswa = new ArrayList<>();
    private Connection con;
    private ResultSet rs;
    private Statement st;
    private String jawabbenar = "";
    private String jawabpilih = "";
    
    //untuk mengambil data static cookies
    private String pelajarannow = "";
    private String paketnow = "";
    @FXML
    private Label testing;
    
    //untuk mengeset jawaban posisi soal
    public void setJawabPilih(String jawabpilih){
        this.jawabpilih = jawabpilih;
    }
    public String getJawabPilih(){
        return jawabpilih;
    }
    
    //untuk membantu memposisikan urutan nomor soal
    private int top;
    public void setTop(int top){
        this.top = top;
    }
    public int getTop(){
        return top;
    }
    
    //untuk menentukan array maksimal milik jmlah soal yg dicollect
    private int max;
    public void setMax(int max){
        this.max=max;
    }
    public int getMax(){
        return max;
    }
    
    @FXML
    private Label achoose;
    @FXML
    private Label bchoose;
    @FXML
    private Label cchoose;
    @FXML
    private Label dchoose;
    @FXML
    private Button soalSebelumnya;
    @FXML
    private Button selesaiButton;
    @FXML
    private ScrollPane paneSuper;
    @FXML
    private Label noSoal;
    @FXML
    private Button aButton;
    @FXML
    private Button bButton;
    @FXML
    private Button cButton;
    @FXML
    private TextArea soalTextArea;
    @FXML
    private Button selanjutnyaButton;
    @FXML
    private Button dButton;
    
        //untuk mewarnai label
    public void highlight(String x , Soal y){
        //ambil string dari jawaban siswa
        String ambilchar = x;
        //membandingkan dengan jawabansoal
        if (ambilchar.equals(y.getJawaba())){
                dchoose.setVisible(false);
                bchoose.setVisible(false);
                cchoose.setVisible(false);
                achoose.setVisible(true);
        } else if (ambilchar.equals(y.getJawabb())){
            dchoose.setVisible(false);
                achoose.setVisible(false);
                cchoose.setVisible(false);
                bchoose.setVisible(true);
        } else if (ambilchar.equals(y.getJawabc())){
            achoose.setVisible(false);
                bchoose.setVisible(false);
                cchoose.setVisible(false);
                cchoose.setVisible(true);
        } else if (ambilchar.equals(y.getJawabd())){
            achoose.setVisible(false);
                bchoose.setVisible(false);
                cchoose.setVisible(false);
                dchoose.setVisible(true);
        } else {
            dchoose.setVisible(false);
                bchoose.setVisible(false);
                cchoose.setVisible(false);
                achoose.setVisible(false);
        }
    }

    
    //this method show soal from selected soal
    public void showSoal (Soal listsoal, int i){
        noSoal.setText(String.valueOf(i)+".");
        soalTextArea.setText(listsoal.getText());
        aButton.setText("A. "+listsoal.getJawaba());
        bButton.setText("B. "+listsoal.getJawabb());
        cButton.setText("C. "+listsoal.getJawabc());
        dButton.setText("D. "+listsoal.getJawabd());
        jawabbenar = listsoal.getJawabanbenar();
    }
    
    //digunakan untuk setsiswa model setter getter
   double score;
    public void setSiswaScore(double x){
        this.score = x;
    }
    public double getScore(){
        return this.score;
    }
   
    //this method collect soal from database
    public void collectSoal(String x, String y){
        try{
            String sql = "select * from "+ x + " where paket = '"+ y +"';";
            System.out.println("query success");
            rs = st.executeQuery(sql);
            while(rs.next()){
                
                //mengisi array dengan soal
                listsoal.add(new Soal(rs.getInt("no"),rs.getString("soal"),rs.getString("paket"),
                        rs.getString("jawaba"),rs.getString("jawabb"),
                rs.getString("jawabc"),rs.getString("jawabd"),rs.getString("jawabanbenar")));
                
                //mengisi array dengan jawaban benar
                listjawabansoal.add(rs.getString("jawabanbenar"));
                
                //mengisi jawaban siswa sementara
                listjawabansiswa.add("kosong");
                pilihan.add('x');
                
                //mengetahui banyak soal didatabase
                int p = getMax();
                p++;
                setMax(p);
            }
            System.out.println("soal loaded");
            System.out.println("max p : "+getMax());
            
        } catch (SQLException e ){
            e.printStackTrace();
        }
    } //keluarin p yg max
    int choosen = 0;
    
    //this method jalan if opsi a terpilih
    @FXML
    public void aButtonClicked (ActionEvent e){
        pilihan.add(getTop(),'x');
        achoose.setVisible(true);
        bchoose.setVisible(false);
        cchoose.setVisible(false);
        dchoose.setVisible(false);
        //ambil string jawaban terpilih
        jawabpilih = "";
        jawabpilih = aButton.getText().substring(3,aButton.getText().length());
        //nyimpan jawaban di array itu
        char c = 'A';
        pilihan.add(getTop(),c);
        System.out.println("pilihan di jawaban itu : "+pilihan.get(getTop()));
        //show jawaban terpilih
        System.out.println("jawaban terpilih diambil substring : "+jawabpilih); 
        //show jawaban yg benar soal itu
        System.out.println("jawaban yg benarnya : "+jawabbenar);
        setJawabPilih(jawabpilih); 
        //info posisi soal dr array
        System.out.println("info posisi soal dr array"+getTop());
        //harusnya overwrite listjawaban
        listjawabansiswa.add(getTop(),getJawabPilih());
        System.out.println("jawaban diset ke : "+listjawabansiswa.get(getTop()));
        testing.setText(listjawabansiswa.get(getTop()));
        //di prev page dan next hrs lihat jawaban di urutan tsb
        selanjutnyaButton.setVisible(true);
        System.out.println("    ");
       
    }
    //this method jalan if opsi b terpilih
    @FXML
    public void bButtonClicked (ActionEvent e){
        pilihan.add(getTop(),'x');
        bchoose.setVisible(true);
        achoose.setVisible(false);
        cchoose.setVisible(false);
        dchoose.setVisible(false);
        //ambil string jawaban terpilih
        jawabpilih = "";
        jawabpilih = bButton.getText().substring(3,bButton.getText().length());
        //nyimpan jawaban di array itu
        char c = 'B';
        pilihan.add(getTop(),c);
        System.out.println("pilihan di jawaban itu : "+pilihan.get(getTop()));
        //show jawaban terpilih
        System.out.println("jawaban terpilih diambil substring : "+jawabpilih); 
        //show jawaban yg benar soal itu
        System.out.println("jawaban yg benarnya : "+jawabbenar);
        setJawabPilih(jawabpilih); 
        //info posisi soal dr array
        System.out.println("info posisi soal dr array"+getTop());
        //harusnya overwrite listjawaban
        listjawabansiswa.add(getTop(),getJawabPilih());
        System.out.println("jawaban diset ke : "+listjawabansiswa.get(getTop()));
        testing.setText(listjawabansiswa.get(getTop()));
        //di prev page dan next hrs lihat jawaban di urutan tsb
        selanjutnyaButton.setVisible(true);
        System.out.println("    ");
    }
    //this method jalan if opsi c terpilih
    @FXML
    public void cButtonClicked (ActionEvent e){
        pilihan.add(getTop(),'x');
        cchoose.setVisible(true);
        bchoose.setVisible(false);
        achoose.setVisible(false);
        dchoose.setVisible(false);
        //ambil string jawaban terpilih
        jawabpilih = "";
        jawabpilih = cButton.getText().substring(3,cButton.getText().length());
        //nyimpan jawaban di array itu
        char c = 'C';
        pilihan.add(getTop(),c);
        System.out.println("pilihan di jawaban itu : "+pilihan.get(getTop()));
        //show jawaban terpilih
        System.out.println("jawaban terpilih diambil substring : "+jawabpilih); 
        //show jawaban yg benar soal itu
        System.out.println("jawaban yg benarnya : "+jawabbenar);
        setJawabPilih(jawabpilih); 
        //info posisi soal dr array
        System.out.println("info posisi soal dr array "+getTop());
        //harusnya overwrite listjawaban work
        listjawabansiswa.add(getTop(),getJawabPilih());
        System.out.println("jawaban diset ke : "+listjawabansiswa.get(getTop()));
        testing.setText(listjawabansiswa.get(getTop()));
        //di prev page dan next hrs lihat jawaban di urutan tsb sudah
        if(getTop()==listsoal.size()-1){
            selanjutnyaButton.setVisible(false);
        } else {
            selanjutnyaButton.setVisible(true);
        }
        System.out.println("    ");
    }
    //this method jalan if opsi d terpilih
    @FXML
    public void dButtonClicked (ActionEvent e){
        pilihan.add(getTop(),'x');
        dchoose.setVisible(true);
        bchoose.setVisible(false);
        cchoose.setVisible(false);
        achoose.setVisible(false);
        //ambil string jawaban terpilih
        jawabpilih = "";
        jawabpilih = dButton.getText().substring(3,dButton.getText().length());
        //nyimpan jawaban di array itu
        char c = 'D';
        pilihan.add(getTop(),c);
        System.out.println("pilihan di jawaban itu : "+pilihan.get(getTop()));
        //show jawaban terpilih
        System.out.println("jawaban terpilih diambil substring : "+jawabpilih); 
        //show jawaban yg benar soal itu
        System.out.println("jawaban yg benarnya : "+jawabbenar);
        setJawabPilih(jawabpilih); 
        //info posisi soal dr array
        System.out.println("info posisi soal dr array"+getTop());
        //harusnya overwrite listjawaban
        listjawabansiswa.add(getTop(),getJawabPilih());
        System.out.println("jawaban diset ke : "+listjawabansiswa.get(getTop()));
        testing.setText(listjawabansiswa.get(getTop()));
        if(getTop()==listsoal.size()-1){
            selanjutnyaButton.setVisible(false);
        } else {
            selanjutnyaButton.setVisible(true);
        }
        //di prev page dan next hrs lihat jawaban di urutan tsb
        System.out.println("    ");
    }
    
    
    //untuk tombol next
    @FXML
    public void selanjutnyaButtonAction (ActionEvent e ) throws IOException{
            int x = getTop();
            x++;
            setTop(x);
            
            
                dchoose.setVisible(false);
                bchoose.setVisible(false);
                cchoose.setVisible(false);
                achoose.setVisible(false);
            
            
            //lihatjawaban diurutan soal tsb debug
            System.out.println("pilihan di jawaban itu : "+pilihan.get(getTop()));
            System.out.println("jawaban diurutan soal : "+listjawabansiswa.get(getTop()));
            
            //sistem
            setJawabPilih("");
            System.out.println("info array di "+getTop());
            System.out.println("atas");
            
            
            //INI BERGUNA
            //show soal to that number
             //showsoalthatnumber
            //untuk menutupi bug
           if (pilihan.get(getTop()).equals('x')){
                pilihan.add(getTop(),'x');
                showSoal(listsoal.get(getTop()),x+1);
                testing.setText(listjawabansiswa.get(getTop()));
            } else {
                pilihan.add(getTop(),pilihan.get(getTop()));
                showSoal(listsoal.get(getTop()),x+1);
                selanjutnyaButton.setVisible(true);
                testing.setText(listjawabansiswa.get(getTop()));
            }

            //tampil tombol main tepi atas
             
             //jika ini soal terakhir dan masih kosong
             //atau ini soal terakhir dan jawaban terisi
            if(getTop()==listsoal.size()-1 && listjawabansiswa.get(getTop()).equals("kosong") ||
                    getTop()==listsoal.size()-1 && !listjawabansiswa.get(getTop()).equals("kosong")){
                 highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                 //tetap tdk bisa next
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(false);
                System.out.println("akhir soal");
                
                //jika soal ini kosong dan selanjutnya masih kosong
            } else if (listjawabansiswa.get(getTop()).equals("kosong") && listjawabansiswa.get(getTop()+1).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                //belum bisa next sebelum terjawab
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(false);
                
                //jika soal selanjutnya tidak kosong dan soal yang saat ini juga tidak kosong
            }else if (!listjawabansiswa.get(getTop()+1).equals("kosong") && !listjawabansiswa.get(getTop()).equals("kosong")) {
                System.out.println("selanjutnya jawaban isi");
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                //bisa maju mundur
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(true);
                
                //jika soal ini terisi dan soal selanjutnya masih kosong
                //atau soal ini terisi yg merupakan soal terakhir
            } else if (!listjawabansiswa.get(getTop()).equals("kosong") && listjawabansiswa.get(getTop()+1).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                //belum bisa next 
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(true);
            } 
            //coba debug nnti dihapus
            highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
            System.out.println("    ");
    }
    //untuk tombol prev
    @FXML
    public void soalSebelumnyaAction (ActionEvent e ) throws IOException{
            int x = getTop();
            x--;
            setTop(x);
            
           dchoose.setVisible(false);
            bchoose.setVisible(false);
            cchoose.setVisible(false);
            achoose.setVisible(false);
            
            //lihatjawaban diurutan soal tsb
            System.out.println("jawaban siswa diurutan itu : "+listjawabansiswa.get(getTop()));
            System.out.println("jawaban benar diurutan itu : "+listjawabansoal.get(getTop()));
            
             //sistem
            setJawabPilih("");
            System.out.println("info array di "+getTop());
            System.out.println("atas");            
            
            //setjawaban ulang saving
            if (pilihan.get(getTop())=='x'){
                pilihan.add(getTop(),'x');
                showSoal(listsoal.get(getTop()),x+1);
                testing.setText(listjawabansiswa.get(getTop()));
            } else if (pilihan.get(getTop())!='x'){
                pilihan.add(getTop(),pilihan.get(getTop()));
                showSoal(listsoal.get(getTop()),x+1);
                testing.setText(listjawabansiswa.get(getTop()));
            }
            
            //tampiltombol mainnya dengan batas bawah
            
            //jika soal ini soal awal dan kosong dan setelahnya juga kosong
            if (getTop()==0 && listjawabansiswa.get(getTop()).equals("kosong") && listjawabansiswa.get(getTop()+1).equals("kosong")) {
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                //dia hanya bisa maju setelah jawab dulu
                soalSebelumnya.setVisible(false);
                selanjutnyaButton.setVisible(false);
                
                //jika dia bukan soal awal dan soal selanjutnya ternyata tidak kosong dan sebelumnya juga tidak kosong
            } else if (getTop() > 0 && !listjawabansiswa.get(getTop()+1).equals("kosong") && !listjawabansiswa.get(getTop()).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(true);
                
                //jika dia soal awal dan soal selanjutnya tidak kosong
            } else if (getTop()==0 && !listjawabansiswa.get(getTop()+1).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                soalSebelumnya.setVisible(false);
                selanjutnyaButton.setVisible(true);
                
                //jika dia bukan soal awal dan masih kosong dan sebelumnya tidak kosong
            } else if (getTop() > 0 && listjawabansiswa.get(getTop()).equals("kosong") && !listjawabansiswa.get(getTop()-1).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(false);
                
                //jika soal ini berisi dan selanjutnya kosong dan soal sebelumnya berisi
            } else if (getTop () > 0 && !listjawabansiswa.get(getTop()).equals("kosong") && listjawabansiswa.get(getTop()+1).equals("kosong")
                    && !listjawabansiswa.get(getTop()-1).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                soalSebelumnya.setVisible(true);
                selanjutnyaButton.setVisible(true);
                
                //jika soal ini awal dan berisi dan selanjutnya kosong
            } else if (getTop () == 0 && !listjawabansiswa.get(getTop()).equals("kosong") && listjawabansiswa.get(getTop()+1).equals("kosong")){
                highlight(listjawabansiswa.get(getTop()),listsoal.get(getTop()));
                soalSebelumnya.setVisible(false);
                selanjutnyaButton.setVisible(true);
            }
            
            System.out.println("    ");
    }
    //untuk tombol finish
    @FXML
    private void selesaiButtonAction(ActionEvent event) throws IOException, SQLException {
        double s = getScore();
        int i = 0;
        
        //mengambil skor dengan membandingkan
        while (i<getTop()){
            if(listjawabansiswa.get(i).equals(listjawabansoal.get(i))){
                s=s+1.0;
            } else {
                s=s+0.0;
            }
            i++;
        }
        
        //setsiswascore double
        int m = getMax();
        System.out.println("m nya :" +m);
        double a = s/m*100.0;
        System.out.println("setSiswaScore() : "+a);
        setSiswaScore(a);
        double thisscore = getScore();
        siswascore = thisscore;
        System.out.println("thisscore : "+thisscore);
        System.out.println("    ");
        
        //clear
        listsoal.clear();
        Cookies.listsoal.clear();
        System.out.println("reset siswascore");
        jawabpilih = "";
        listsoal.clear();
        listjawabansoal.clear();
        jawabanbenar.clear();
        listjawabansiswa.clear();
        
        //go hasil siswa
        System.out.println("go hasilsiswa");
        Stage stage = null; Parent root = null; Scene scene = null;
        stage = (Stage) selesaiButton.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("/tubes/View/hasilSiswa.fxml"));
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //connect
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        
        //cek di tubes output
        System.out.println(pelajaranactive);
        System.out.println(paketactive);
        
        //menyembunyikan label terpilih
        dchoose.setVisible(false);
        bchoose.setVisible(false);
        cchoose.setVisible(false);
        achoose.setVisible(false);
        
        //set yg di static cookies
        setTop(icookies);
        System.out.println(getTop());
        
        //harusnya ini jadi procedure tp mager
        if (pelajaranactive.equals("Bahasa Indonesia")&&paketactive.equals("Paket 1")){
                pelajarannow = "soalindo";
                paketnow = "paket1";
            } else if(pelajaranactive.equals("Bahasa Indonesia")&&paketactive.equals("Paket 2")){
                pelajarannow = "soalindo";
                paketnow = "paket2";
            } else if (pelajaranactive.equals("Matematika")&&paketactive.equals("Paket 1")){
                pelajarannow = "soalmtk";
                paketnow = "paket1";
            } else if (pelajaranactive.equals("Matematika")&&paketactive.equals("Paket 2")){
                pelajarannow = "soalmtk";
                paketnow = "paket2";
            } else if (pelajaranactive.equals("IPA")&&paketactive.equals("Paket 1")){
                pelajarannow = "soalipa";
                paketnow = "paket1";
            } else if (pelajaranactive.equals("IPA")&&paketactive.equals("Paket 2")){
                pelajarannow = "soalipa";
                paketnow = "paket2";
            }
        //mengumpulkan soal lewat procedure ini
        collectSoal(pelajarannow,paketnow);
        
        //setcookies di list soal
        Cookies.listsoal = this.listsoal;
        
        //lihatjawaban diurutan soal tsb
            System.out.println("jawaban diurutan soal : "+listjawabansiswa.get(getTop()));
            System.out.println("    ");
            
        //setinfosoal
        
            
        //ambil posisi soal
        showSoal(listsoal.get(getTop()),getTop()+1);
        
        //settombol
        soalSebelumnya.setVisible(false);
        selanjutnyaButton.setVisible(false);
    }
}
