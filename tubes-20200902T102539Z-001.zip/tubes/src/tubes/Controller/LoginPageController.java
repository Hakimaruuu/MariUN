/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static tubes.Modul.Cookies.passwordactive;
import static tubes.Modul.Cookies.useractive;
import static tubes.Modul.Cookies.nisnactive;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class LoginPageController implements Initializable {
    //DATABASE
    String sql;
    Connection con;
    ResultSet rs;
    Statement st;
    /**
     * Initializes the controller class.
     */
    Stage prevStage;
    @FXML
    private Button registerButton;
    @FXML
    private TextField loginUsername;
    
    public String getloginUsername(){
        return loginUsername.getText();
    }
    @FXML
    private PasswordField loginPassword;
    public String getloginPassword(){
        return loginPassword.getText();
    }
    @FXML
    private Button loginButton;
    
    @FXML
    private Label loginSalah;
    
    public void setPrevStage(Stage stage){
        this.prevStage = stage;
    }
    @FXML
    private void handleregisterButtonAction(ActionEvent ev) throws IOException{
          Stage stage = null;
          Parent root = null;
          Scene scene = null;
          stage = (Stage) registerButton.getScene().getWindow();
          root = FXMLLoader.load(getClass().getResource("/tubes/View/registerPage.fxml"));
          scene = new Scene(root);
          stage.setScene(scene);
          stage.show();
    }
    @FXML
    private void handleloginButtonAction(ActionEvent Event) throws IOException, SQLException{
        FXMLLoader user = new FXMLLoader();
        user.setLocation(getClass().getResource("/tubes/View/userDashboard.fxml"));
        Stage stage = null;
        Parent root = null;
        Scene scene = null;
        String yes = "yes";
        
        try {
            String sql = "select * from user where username ='"+loginUsername.getText()+"'"
                    + " AND password ='"+loginPassword.getText()+"';";
            rs = st.executeQuery(sql);
            
            if (rs.next()){
                if (loginUsername.getText().equals(rs.getString("username")) && 
                        loginPassword.getText().equals(rs.getString("password"))){
                    
                    //save to cookies
                    useractive = rs.getString("nama");
                    passwordactive = rs.getString("password");  
                    nisnactive = rs.getString("nisn");
                    
                    if (rs.getString("guru").equals("no")){
                           System.out.println("guru no");
                           Alert alert = new Alert(AlertType.INFORMATION);
                           alert.setTitle("Peringatan");
                           alert.setHeaderText(null);
                           alert.setContentText("Login Siswa Successful");
                           alert.showAndWait();
                           stage = (Stage) loginButton.getScene().getWindow();
                           root = FXMLLoader.load(getClass().getResource("/tubes/View/userDashboard.fxml"));
                           scene = new Scene(root);
                           stage.setScene(scene);
                           stage.show();
                    } else if(rs.getString("guru").equals("admin")) {
                           System.out.println("guru no");
                           Alert alert = new Alert(AlertType.INFORMATION);
                           alert.setTitle("Peringatan");
                           alert.setHeaderText(null);
                           alert.setContentText("Login Admin Successful");
                           alert.showAndWait();
                           stage = (Stage) loginButton.getScene().getWindow();
                           root = FXMLLoader.load(getClass().getResource("/tubes/View/admin/adminDashboard.fxml"));
                           scene = new Scene(root);
                           stage.setScene(scene);
                           stage.show();
                    }
                    else {
                        System.out.println("guru yes");
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Peringatan");
                        alert.setHeaderText(null);
                        alert.setContentText("Login Guru Successful");
                        alert.showAndWait();
                        stage = (Stage) loginButton.getScene().getWindow();
                        root = FXMLLoader.load(getClass().getResource("/tubes/View/guru/guruDashboard.fxml"));
                        scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                    }
                } 
            }  else {
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Peringatan");
                    alert.setHeaderText(null);
                    alert.setContentText("Data Salah atau Tidak ada");
                    alert.showAndWait();
                   loginSalah.setText("Data yang dimasukkan salah!");
                }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         Database db = new Database();
         db.connect();
         con = db.conn;
         st = db.statement;
    }
}
