/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class SplashScreenController implements Initializable {

    @FXML
    private Label loadingtext;
    @FXML
    public  Rectangle loadingbar;
    
    int i = 0; int b =0;
    class splash extends Thread{
        @Override
        public void run(){    
            try{
                loadingbar.setWidth(0);
                loadingtext.setText("");
                while(i <= 460){
                    System.out.println(i);
                    int a = i;
                    b =25*i;
                    loadingbar.setWidth(a);
                    Thread.sleep(50);
                    i=i+10;
                }
                Platform.runLater(()-> {
                    try{
                        Parent root = FXMLLoader.load(getClass().getResource("/tubes/View/loginPage.fxml"));
                        Stage stage = (Stage) loadingbar.getScene().getWindow();
                        Scene sc = new Scene(root);
                        stage.setScene(sc);
                        stage.show();
                    }catch (IOException ex){
                        Logger.getLogger(SplashScreenController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                });
            } catch(InterruptedException ex){
                Logger.getLogger(SplashScreenController.class.getName()).log(Level.SEVERE, null, ex);
            
            }
        
            }
        }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
            new splash().start();
    }    
    
}
