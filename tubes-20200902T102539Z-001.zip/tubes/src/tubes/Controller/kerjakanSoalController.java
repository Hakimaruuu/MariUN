/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import static tubes.Modul.Cookies.paketactive;
import static tubes.Modul.Cookies.pelajaranactive;


/**
 * FXML Controller class
 *
 * @author rizki
 */
public class kerjakanSoalController implements Initializable {
    
    @FXML
    private ComboBox<String> comboMataPelajaran;
    @FXML
    private ComboBox<String> comboPaket;
    @FXML
    private Button buttonMulai;
    
    @FXML
    private void buttonMulaiClicked (ActionEvent evet) throws IOException{
        String pelajaran = comboMataPelajaran.getValue();
        String paket = comboPaket.getValue();
        
        Stage stage = null;
        Parent root = null;
        Scene scene = null;
        
        if(pelajaran.equals("Bahasa Indonesia")&&paket.equals("Paket 1")){
             stage = (Stage) buttonMulai.getScene().getWindow();
             root = FXMLLoader.load(getClass().getResource("/tubes/View/lembarSoal.fxml"));
             paketactive = "Paket 1"; pelajaranactive = "Bahasa Indonesia";
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else if(pelajaran.equals("Bahasa Indonesia")&&paket.equals("Paket 2")){
             stage = (Stage) buttonMulai.getScene().getWindow();
             root = FXMLLoader.load(getClass().getResource("/tubes/View/lembarSoal.fxml"));
             paketactive = "Paket 2"; pelajaranactive = "Bahasa Indonesia";
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else if(pelajaran.equals("Matematika")&&paket.equals("Paket 1")){
             stage = (Stage) buttonMulai.getScene().getWindow();
             root = FXMLLoader.load(getClass().getResource("/tubes/View/lembarSoal.fxml"));
             paketactive = "Paket 1"; pelajaranactive = "Matematika";
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else if(pelajaran.equals("Matematika")&&paket.equals("Paket 2")){
             stage = (Stage) buttonMulai.getScene().getWindow();
             root = FXMLLoader.load(getClass().getResource("/tubes/View/lembarSoal.fxml.fxml"));
             paketactive = "Paket 2"; pelajaranactive = "Matematika";
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else if(pelajaran.equals("IPA")&&paket.equals("Paket 1")){
             stage = (Stage) buttonMulai.getScene().getWindow();
             root = FXMLLoader.load(getClass().getResource("/tubes/View/lembarSoal.fxml"));
             paketactive = "Paket 1"; pelajaranactive = "IPA";
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else if(pelajaran.equals("IPA")&&paket.equals("Paket 2")){
             stage = (Stage) buttonMulai.getScene().getWindow();
             root = FXMLLoader.load(getClass().getResource("/tubes/View/lembarSoal.fxml"));
             paketactive = "Paket 2"; pelajaranactive = "IPA";
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        ObservableList<String> listcomboMataPelajaran = FXCollections
            .observableArrayList("Bahasa Indonesia", "Matematika","IPA");
        
        ObservableList<String> listcomboPaket = FXCollections
            .observableArrayList("Paket 1", "Paket 2");

        comboMataPelajaran.setValue("Bahasa Indonesia");
        comboMataPelajaran.setItems(listcomboMataPelajaran);
        comboPaket.setValue("Paket 1");
        comboPaket.setItems(listcomboPaket);
        
    }    
    
}
