/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import static tubes.Modul.Cookies.paketactive;
import static tubes.Modul.Cookies.pelajaranactive;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class LembarSoalController implements Initializable {

    private Connection con;
    private ResultSet rs;
    private Statement st;
    private int nosoal = 0;
    String setpelajaran; String setpaket;
    
    @FXML
    private ScrollPane paneSuper;
    @FXML
    private Button selanjutnyaButton;
    @FXML
    private Label labelpelajaranpaket;
    private Label labeltimer;
   
    @FXML
    public void selanjutnyaButtonAction(ActionEvent av) throws IOException {
        ScrollPane sp = FXMLLoader.load(getClass().getResource("/tubes/View/indoPaneSoal.fxml"));
        paneSuper.setContent(sp);
    }

    @FXML
    private void sel(ActionEvent event) {
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        labelpelajaranpaket.setText(pelajaranactive+ " " +paketactive);
        
    }    
    
}
