/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller.admin;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import static tubes.Modul.Cookies.useractive;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class AdminDashboardController implements Initializable {

    @FXML
    private Label labelKerjaSoal;
    @FXML
    private Label labelNilai;
    @FXML
    private Label labelAkun;
    @FXML
    private Label labelKontakAdmin;
    @FXML
    private Label labelKeluar;
    @FXML
    private Button menuKerjakanSoal;
    @FXML
    private Button menuLihatNilai;
    @FXML
    private Button menuAkun;
    @FXML
    private Button menuKontakAdmin;
    @FXML
    private Button menuKeluar;
    @FXML
    private Button menuHome;
    @FXML
    private ScrollPane paneSuper;
    @FXML
    private Label userGreeting;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        userGreeting.setText(useractive);
    }    

    @FXML
    private void menuKerjakanSoalAction(ActionEvent event) {
        try {
            labelKerjaSoal.setBackground(new Background(new BackgroundFill(Color.valueOf("brown"), CornerRadii.EMPTY, Insets.EMPTY)));
            labelNilai.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelAkun.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelKontakAdmin.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            ScrollPane sp = FXMLLoader.load(getClass().getResource("/tubes/View/admin/formTambahGuru.fxml"));
            paneSuper.setContent(sp);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    @FXML
    private void menuLihatNilaiAction(ActionEvent event) {
        try {
            labelKerjaSoal.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelNilai.setBackground(new Background(new BackgroundFill(Color.valueOf("brown"), CornerRadii.EMPTY, Insets.EMPTY)));
            labelAkun.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelKontakAdmin.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            ScrollPane sp = FXMLLoader.load(getClass().getResource("/tubes/View/admin/formTambahSiswa.fxml"));
            paneSuper.setContent(sp);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    @FXML
    private void menuAturAkunClicked(ActionEvent event) {
        try {
            labelKerjaSoal.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelNilai.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelAkun.setBackground(new Background(new BackgroundFill(Color.valueOf("brown"), CornerRadii.EMPTY, Insets.EMPTY)));
            labelKontakAdmin.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            ScrollPane sp = FXMLLoader.load(getClass().getResource("/tubes/View/admin/formHapusSiswa.fxml"));
            paneSuper.setContent(sp);
        } catch (IOException e) {
            System.out.println(e);
        } 
    }

    @FXML
    private void menuKontakAdminClicked(ActionEvent event) {
        try {
            labelKerjaSoal.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelNilai.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelAkun.setBackground(new Background(new BackgroundFill(Color.TRANSPARENT, CornerRadii.EMPTY, Insets.EMPTY)));
            labelKontakAdmin.setBackground(new Background(new BackgroundFill(Color.valueOf("brown"), CornerRadii.EMPTY, Insets.EMPTY)));
            ScrollPane sp = FXMLLoader.load(getClass().getResource("/tubes/View/admin/formHapusGuru.fxml"));
            paneSuper.setContent(sp);
        } catch (IOException e) {
            System.out.println(e);
        } 
    }

    @FXML
    private void menuKeluarMenuAction(ActionEvent event) throws IOException {
        Stage stage = null;
         stage = (Stage) menuKeluar.getScene().getWindow();
         Parent root = FXMLLoader.load(getClass().getResource("/tubes/View/loginPage.fxml"));
         Scene scene = new Scene(root);
         stage.setScene(scene);
         stage.setTitle("Simulasi UN Sekolah Dasar 2019");   
         stage.show();
    }
    
}
