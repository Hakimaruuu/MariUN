/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller.manager;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author rizki
 */
public class lihatSiswaView {
    private SimpleStringProperty username;
    private SimpleStringProperty nama;
    private SimpleStringProperty password;
    private SimpleStringProperty nisn;

    public String getUsername() {
        return username.get();
    }

    public String getNama() {
        return nama.get();
    }

    public String getPassword() {
        return password.get();
    }
    public String getNisn() {
        return nisn.get();
    }

    public lihatSiswaView(SimpleStringProperty username, SimpleStringProperty nama, SimpleStringProperty password, SimpleStringProperty nisn) {
        this.username = username;
        this.nama = nama;
        this.password = password;
        this.nisn = nisn;
    }

}
