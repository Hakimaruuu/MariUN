/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller.manager;

import java.sql.Date;
import java.text.SimpleDateFormat;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;


/**
 *
 * @author rizki
 */
public class lihatNilaiView {
    private SimpleIntegerProperty no;
    private Date date;
    private SimpleDoubleProperty score;
    private SimpleStringProperty pelajaran;
    private SimpleStringProperty index;
    private SimpleStringProperty paket;
    SimpleDateFormat simpledateformat = new SimpleDateFormat("dd-MM-yyyy");

    public lihatNilaiView(int no, Date date, Double score, String pelajaran, String paket) {
        this.no = new SimpleIntegerProperty(no);
        
        this.date = date;
        this.score = new SimpleDoubleProperty(score);
        this.pelajaran = new SimpleStringProperty(pelajaran);
        if(score>80){
            this.index = new SimpleStringProperty("A");
        } else if (score>60 && score<79){
            this.index = new SimpleStringProperty("B");
        } else {
            this.index = new SimpleStringProperty("C");
        }
        this.paket = new SimpleStringProperty(paket);
    }

    public Integer getNo() {
        return no.get();
    }

    public Date getDate() {
        return date;
    }

    public Double getScore() {
        return score.get();
    }

    public String getPelajaran() {
        return pelajaran.get();
    }

    public String getIndex() {
        return index.get();
    }

    public String getPaket() {
        return paket.get();
    }
    
    
    
}
