/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import static tubes.Modul.Cookies.paketactive;
import static tubes.Modul.Cookies.pelajaranactive;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class FormTambahSoalController implements Initializable {
    
    Connection con;
    ResultSet rs;
    Statement st;
    PreparedStatement ps;

    @FXML
    private ScrollPane paneSuper;
    @FXML
    private Label noSoal;
    @FXML
    private TextArea soalTextArea;
    @FXML
    private Button uploadSoal;
    @FXML
    private Button selesaiButton;
    @FXML
    private Label achoose;
    @FXML
    private Label bchoose;
    @FXML
    private Label cchoose;
    @FXML
    private Label dchoose;
    @FXML
    private TextField fielda;
    @FXML
    private TextField fieldb;
    @FXML
    private TextField fieldc;
    @FXML
    private TextField fieldd;
    @FXML
    private RadioButton rbuttonA;
    @FXML
    private RadioButton rbuttonB;
    @FXML
    private RadioButton rButtonC;
    @FXML
    private RadioButton rbuttonD;
    @FXML
    private ToggleGroup group;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        System.out.println(pelajaranactive);
        System.out.println(paketactive);
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        
        // TODO
    }    

    String isisoal = "";
    String opsia = "";
    String opsib = "";
    String opsic = "";
    String opsid = "";
    String pelajarannow;
    String paketnow;
    String jawabanygbenar;
    
    int number = 0;
    public void setNumber(int number){
        this.number = number;
    }
    public int getNumber(){
        return number;
    }
    
    @FXML
    private void selanjutnyaButtonAction(ActionEvent event) throws SQLException {
        if(!soalTextArea.getText().isEmpty() || !fielda.getText().isEmpty() || !fieldb.getText().isEmpty()
                || !fieldc.getText().isEmpty() || !fieldd.getText().isEmpty()){
            isisoal = soalTextArea.getText();
            opsia = fielda.getText();
            opsib = fieldb.getText();
            opsic = fieldc.getText();
            opsid = fieldd.getText();
            if (pelajaranactive.equals("Bahasa Indonesia")&&paketactive.equals("Paket 1")){
                pelajarannow = "soalindo";
                paketnow = "paket1";
            } else if(pelajaranactive.equals("Bahasa Indonesia")&&paketactive.equals("Paket 2")){
                pelajarannow = "soalindo";
                paketnow = "paket2";
            } else if (pelajaranactive.equals("Matematika")&&paketactive.equals("Paket 1")){
                pelajarannow = "soalmtk";
                paketnow = "paket1";
            } else if (pelajaranactive.equals("Matematika")&&paketactive.equals("Paket 2")){
                pelajarannow = "soalmtk";
                paketnow = "paket2";
            } else if (pelajaranactive.equals("IPA")&&paketactive.equals("Paket 1")){
                pelajarannow = "soalipa";
                paketnow = "paket1";
            } else if (pelajaranactive.equals("IPA")&&paketactive.equals("Paket 2")){
                pelajarannow = "soalipa";
                paketnow = "paket2";
            }
            
            
            String a = "select * from "+pelajarannow+";";
            rs = st.executeQuery(a);
            while(rs.next()){
                setNumber(Integer.parseInt(rs.getString("no")));
            }
            int r = getNumber()+1;
            System.out.println(r);
        
            
            if(rbuttonA.isSelected()){
                jawabanygbenar = opsia;
            } else if(rbuttonB.isSelected()){
                jawabanygbenar = opsib;
            } else if (rButtonC.isSelected()){
                jawabanygbenar = opsic;
            } else if (rbuttonD.isSelected()){
                jawabanygbenar = opsid;
            }
            String q = String.valueOf(r);
            System.out.println(q);
            String sqla = "insert into "+pelajarannow+" values( ? , ? , ? , ? , ? , ? , ? , ? );";
            ps = con.prepareStatement(sqla);
            ps.setInt(1, r);
            ps.setString(2, isisoal);
            ps.setString(3, paketnow);
            ps.setString(4, opsia);
            ps.setString(5, opsib);
            ps.setString(6, opsic);
            ps.setString(7, opsid);
            ps.setString(8, jawabanygbenar);
            ps.executeUpdate();
            System.out.println("sukses");
            soalTextArea.clear(); fielda.clear(); fieldb.clear(); fieldc.clear(); fieldd.clear();
            isisoal = ""; opsia = ""; opsib = ""; opsic =""; opsid = ""; r = 0; jawabanygbenar = "";
            System.out.println("semua clear()");
        } else {
            System.out.println("tidak bisa ada field kosong");
        }
    }

    @FXML
    private void selesaiButtonAction(ActionEvent event) throws IOException {
        Stage stage = null;
        Parent root = null;
        Scene scene = null;
        stage = (Stage) selesaiButton.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("/tubes/View/guru/guruDashboard.fxml"));
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        pelajarannow = "";
        paketnow = "";
    }
    
}
