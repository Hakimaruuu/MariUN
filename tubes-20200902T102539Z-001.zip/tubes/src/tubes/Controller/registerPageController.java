/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class registerPageController implements Initializable {

    Connection con;
    Statement st;
    ResultSet rs;
    PreparedStatement ps;
    
    @FXML
    private PasswordField newPassword;
    @FXML
    private Label loginSalah;
    @FXML
    private TextField nama;
    @FXML
    private TextField username;
    @FXML
    private TextField nisn;
    @FXML
    private Button daftarButton;
    @FXML
    private Label labelinfo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Database db = new Database();
        db.connect();
        con=db.conn;
        st=db.statement;
    }
    
    @FXML
    private void handledaftarLoginButton(ActionEvent ev) throws SQLException{
        if(!nama.getText().isEmpty() || !username.getText().isEmpty() || !newPassword.getText().isEmpty()
                || !nisn.getText().isEmpty()){
            String sql = "insert into user values ( ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, username.getText());
            ps.setString(2, nama.getText());
            ps.setString(3, newPassword.getText());
            ps.setString(4, nisn.getText());
            ps.setString(5, "no");
            ps.executeUpdate();
        } else {
            labelinfo.setText("Data ada kosong atau salah");
        }
    }
}
    
