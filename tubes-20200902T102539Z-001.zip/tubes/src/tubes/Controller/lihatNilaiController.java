/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes.Controller;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import tubes.Controller.manager.lihatNilaiView;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import static tubes.Modul.Cookies.nisnactive;
import static tubes.Modul.Cookies.useractive;
import tubes.Modul.Database;

/**
 * FXML Controller class
 *
 * @author rizki
 */
public class lihatNilaiController implements Initializable {

    Connection con;
    Statement st;
    ResultSet rs;
    
    @FXML
    private Label userActive;
    //DATABASE
    
    public void initData(String x, String y){
        String activeUsername = x;
        String activePass = y;
        userActive.setText(x);
    }
    
    @FXML
    private TableColumn<lihatNilaiView, Integer> no;
    @FXML
    private TableColumn<lihatNilaiView,Timestamp> date;
    @FXML
    private TableColumn<lihatNilaiView, Double> score;
    @FXML
    private TableColumn<lihatNilaiView, String> pelajaran;
    @FXML
    private TableColumn<lihatNilaiView, String> index;
    @FXML
    private TableColumn<lihatNilaiView, String> paket;
    @FXML
    private TableView<lihatNilaiView> table;

    //formater tanggal
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    
    int x = 0;
    public void setX(int x){
        this.x = x;
    }
    public int getX(){
        return x;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Database db = new Database();
        db.connect();
        con = db.conn;
        st = db.statement;
        
        userActive.setText(useractive);
        
        no.setCellValueFactory(new PropertyValueFactory<>("no"));
        System.out.println("run1");
        date.setCellValueFactory(new PropertyValueFactory<>("date"));
                System.out.println("run1");

        score.setCellValueFactory(new PropertyValueFactory<>("score"));
                System.out.println("run1");

        pelajaran.setCellValueFactory(new PropertyValueFactory<>("pelajaran"));
                System.out.println("run1");

        index.setCellValueFactory(new PropertyValueFactory<>("index"));
                System.out.println("run1");

        paket.setCellValueFactory(new PropertyValueFactory<>("paket"));
                System.out.println("run1");

         //set iterasi tabel
                setX(1);       
        
         ObservableList<lihatNilaiView> list = FXCollections.observableArrayList();
         int x =0; String date =  "";
        //connect database
        String sql = "select * from historisiswa where nisn ='"+nisnactive+"';";
        System.out.println("nisn active : "+nisnactive);
        try {
            rs = st.executeQuery(sql);
            while(rs.next()){
                x++;
                System.out.println("lihatNilaiView");
                list.add(new lihatNilaiView(
                        x,
                        rs.getDate("date"),
                        rs.getDouble("score"),
                        rs.getString("pelajaran"),
                        rs.getString("paket")
                ));
                
                System.out.println("list lihat nilai view loaded "+x+" time");
           }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
       
        //showtable
        table.setItems(list);
    }    
    
}
